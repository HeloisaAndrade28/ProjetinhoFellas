package Modelo;

public interface ContaInterface {
    public void addPagamento(Pagamento p) throws Exception;

}
